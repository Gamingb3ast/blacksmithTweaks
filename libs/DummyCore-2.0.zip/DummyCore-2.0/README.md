DummyCore
=========
This branch is a dev builds branch.
DummyCore is a package required for mods made by dummy thinking. It also can be used in another projects.
All sources are here, so you can create your mods using DummyCore, or even modify the core.
