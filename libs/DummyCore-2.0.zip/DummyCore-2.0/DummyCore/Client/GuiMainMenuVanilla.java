package DummyCore.Client;

import net.minecraft.client.gui.GuiMainMenu;
import DummyCore.Utils.IMainMenu;

public class GuiMainMenuVanilla extends GuiMainMenu implements IMainMenu{

}
