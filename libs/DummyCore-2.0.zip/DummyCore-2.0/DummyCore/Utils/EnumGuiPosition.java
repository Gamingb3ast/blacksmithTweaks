package DummyCore.Utils;

@Deprecated
public enum EnumGuiPosition {
	TOPLEFT,
	TOPRIGHT,
	BOTLEFT,
	BOTRIGHT,
	CENTER;
	
	public int x;
	public int y;
	EnumGuiPosition()
	{
	}
	
	

}
