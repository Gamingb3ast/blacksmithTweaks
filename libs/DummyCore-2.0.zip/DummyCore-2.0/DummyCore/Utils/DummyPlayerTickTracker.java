package DummyCore.Utils;

@Deprecated
public class DummyPlayerTickTracker {

}
