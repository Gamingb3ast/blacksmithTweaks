package DummyCore.Utils;

public interface ITEHasGameData {
	
	public abstract String getData();
	
	public abstract void setData(DummyData[] data);
	
	public abstract Coord3D getPosition();

}
