package DummyCore.Utils;

public interface IMainMenu {

}
