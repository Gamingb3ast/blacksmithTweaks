package DummyCore.Utils;

public @interface DCASMCheck {

}
