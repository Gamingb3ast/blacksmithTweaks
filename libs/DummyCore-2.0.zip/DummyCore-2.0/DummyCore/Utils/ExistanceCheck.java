package DummyCore.Utils;

public @interface ExistanceCheck {
	
	String[] classPath();

}
